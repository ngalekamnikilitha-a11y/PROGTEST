/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingreport;

/**
 *
 * @author ngale
 */

import java.util.Arrays;

public class GamingReport {

    public static void main(String[] args) {
        // -------------------------------------------------------------
        // 1D Arrays: Storing categories (Cities and Consoles)
        // -------------------------------------------------------------
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        String[] consoles = {"PS5", "XBOX", "SWITCH"};

        int numCities = cities.length;
        int numConsoles = consoles.length;

        // -------------------------------------------------------------
        // 2D Array: Stores units sold [City Index][Console Index]
        // -------------------------------------------------------------
        int[][] sales = {
            {1000, 2000, 1500}, // PS5
            {2000, 3000, 1100}, // XBOX
            {3000, 4000, 1200}, //SWITCH
            
        };

        // 1D Arrays to hold calculated total sales
        int[] totalSalesByCity = new int[numCities];
        int[] totalSalesByConsole = new int[numConsoles];
        int grandTotal = 0;

        // -------------------------------------------------------------
        // Calculate totals using nested loops
        // -------------------------------------------------------------
        for (int i = 0; i < numCities; i++) {
            for (int j = 0; j < numConsoles; j++) {
                totalSalesByCity[i] += sales[i][j];         // Total for each city
                totalSalesByConsole[j] += sales[i][j];      // Total for each console
                grandTotal += sales[i][j];                   // Overall grand total
            }
        }

        // -------------------------------------------------------------
        // Report 1: Sales Matrix Table
        // -------------------------------------------------------------
        System.out.println("=========================================================================");
        System.out.println("                       GAMING CONSOLE SALES REPORT                       ");
        System.out.println("=========================================================================\n");

        // Table Header
        System.out.printf("%-12s", "City");
        for (int j = 0; j < numConsoles; j++) {
            System.out.printf("%18s", consoles[j]);
        }
        System.out.printf("%15s%n", "Total Sales");
        System.out.println("-".repeat(73));

        // Table Data (Cities and Console Sales)
        for (int i = 0; i < numCities; i++) {
            System.out.printf("%-12s", cities[i]);
            for (int j = 0; j < numConsoles; j++) {
                System.out.printf("%18d", sales[i][j]);
            }
            System.out.printf("%15d%n", totalSalesByCity[i]);
        }

        // Table Footer (Total Sales per Console)
        System.out.println("-".repeat(73));
        System.out.printf("%-12s", "Console Total");
        for (int j = 0; j < numConsoles; j++) {
            System.out.printf("%18d", totalSalesByConsole[j]);
        }
        System.out.printf("%15d%n%n", grandTotal);

        // -------------------------------------------------------------
        // Report 2: Most Console Sales in Each City
        // -------------------------------------------------------------
        System.out.println("=========================================================================");
        System.out.println("                    TOP SELLING CONSOLE BY CITY                          ");
        System.out.println("=========================================================================");

        for (int i = 0; i < numCities; i++) {
            int maxSalesInCity = sales[i][0];
            int topConsoleIndex = 0;

            for (int j = 1; j < numConsoles; j++) {
                if (sales[i][j] > maxSalesInCity) {
                    maxSalesInCity = sales[i][j];
                    topConsoleIndex = j;
                }
            }

            System.out.printf("In %-10s Most Sold = %-16s (%d units)%n", 
                cities[i] + ":", consoles[topConsoleIndex], maxSalesInCity);
        }

        // -------------------------------------------------------------
        // Report 3: Overall Best-Selling Console
        // -------------------------------------------------------------
        int bestOverallConsoleIndex = 0;
        int maxOverallSales = totalSalesByConsole[0];

        for (int j = 1; j < numConsoles; j++) {
            if (totalSalesByConsole[j] > maxOverallSales) {
                maxOverallSales = totalSalesByConsole[j];
                bestOverallConsoleIndex = j;
            }
        }

        System.out.println("\n-------------------------------------------------------------------------");
        System.out.printf("OVERALL BEST SELLER: %s with %d total units sold worldwide.%n", 
            consoles[bestOverallConsoleIndex], maxOverallSales);
        System.out.println("-------------------------------------------------------------------------");
    }
}
