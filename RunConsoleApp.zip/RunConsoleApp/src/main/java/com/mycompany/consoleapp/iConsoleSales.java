/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.consoleapp;

/**
 *
 * @author ngale
 */
public interface iConsoleSales {
    String getCity();
    String getConsole();
    int getSalesAmount();
    double getCalculatedSalesTax();
}