/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consoleapp;

/**
 *
 * @author ngale
 */
public class ConsoleSalesReport extends ConsoleSales {

    public ConsoleSalesReport(String city, String console, int salesAmount) {
        super(city, console, salesAmount);
    }

    public static void printSalesReport(String[] cities, String[] consoles, int[][] sales) {
        int numCities = cities.length;
        int numConsoles = consoles.length;

        int[] totalSalesByCity = new int[numCities];
        int[] totalSalesByConsole = new int[numConsoles];
        int grandTotal = 0;

        // Calculate Totals
        for (int i = 0; i < numCities; i++) {
            for (int j = 0; j < numConsoles; j++) {
                totalSalesByCity[i] += sales[i][j];
                totalSalesByConsole[j] += sales[i][j];
                grandTotal += sales[i][j];
            }
        }

        // Report 1: Matrix Table
        System.out.println("=========================================================================");
        System.out.println("                        GAMING CONSOLE SALES REPORT                      ");
        System.out.println("=========================================================================\n");

        System.out.printf("%-18s", "City");
        for (String console : consoles) {
            System.out.printf("%15s", console);
        }
        System.out.printf("%15s%n", "Total Sales");
        System.out.println("-".repeat(78));

        for (int i = 0; i < numCities; i++) {
            System.out.printf("%-18s", cities[i]);
            for (int j = 0; j < numConsoles; j++) {
                System.out.printf("%15d", sales[i][j]);
            }
            System.out.printf("%15d%n", totalSalesByCity[i]);
        }

        System.out.println("-".repeat(78));
        System.out.printf("%-18s", "Console Total");
        for (int j = 0; j < numConsoles; j++) {
            System.out.printf("%15d", totalSalesByConsole[j]);
        }
        System.out.printf("%15d%n%n", grandTotal);

        // Report 2: Top Selling Console by City
        System.out.println("=========================================================================");
        System.out.println("                         TOP SELLING CONSOLE BY CITY                     ");
        System.out.println("=========================================================================");

        for (int i = 0; i < numCities; i++) {
            int maxSales = sales[i][0];
            int topIndex = 0;
            for (int j = 1; j < numConsoles; j++) {
                if (sales[i][j] > maxSales) {
                    maxSales = sales[i][j];
                    topIndex = j;
                }
            }
            System.out.printf("In %-16s Most Sold = %-8s (%d units)%n", 
                cities[i] + ":", consoles[topIndex], maxSales);
        }

        // Report 3: Overall Best Seller
        int bestConsoleIndex = 0;
        int maxOverall = totalSalesByConsole[0];
        for (int j = 1; j < numConsoles; j++) {
            if (totalSalesByConsole[j] > maxOverall) {
                maxOverall = totalSalesByConsole[j];
                bestConsoleIndex = j;
            }
        }

        System.out.println("\n-------------------------------------------------------------------------");
        System.out.printf("OVERALL BEST SELLER: %s with %d total units sold across all cities.%n", 
            consoles[bestConsoleIndex], maxOverall);
        System.out.println("-------------------------------------------------------------------------");
    }
}
