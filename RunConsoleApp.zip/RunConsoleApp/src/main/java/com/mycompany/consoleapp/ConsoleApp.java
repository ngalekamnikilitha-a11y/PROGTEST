/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consoleapp;

/**
 *
 * @author ngale
 */

public class ConsoleApp {
    public static void main(String[] args) {
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        String[] consoles = {"PS5", "XBOX", "SWITCH"};

        int[][] sales = {
            {1000, 2000, 1500}, // Cape Town
            {2000, 3000, 1100}, // Port Elizabeth
            {3000, 4000, 1200}  // Pretoria
        };

        // Call the static report generator method
        ConsoleSalesReport.printSalesReport(cities, consoles, sales);
    }
}