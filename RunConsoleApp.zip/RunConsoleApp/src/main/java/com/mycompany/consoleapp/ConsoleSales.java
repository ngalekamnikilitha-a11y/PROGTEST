/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consoleapp;

/**
 *
 * @author ngale
 */

public abstract class ConsoleSales implements iConsoleSales {
    private String city;
    private String console;
    private int salesAmount;

    public ConsoleSales(String city, String console, int salesAmount) {
        this.city = city;
        this.console = console;
        this.salesAmount = salesAmount;
    }

    @Override
    public String getCity() {
        return city;
    }

    @Override
    public String getConsole() {
        return console;
    }

    @Override
    public int getSalesAmount() {
        return salesAmount;
    }

    @Override
    public double getCalculatedSalesTax() {
        return salesAmount * 0.15;
    }
}