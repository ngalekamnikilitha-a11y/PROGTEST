/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.runapplication;

/**
 *
 * @author ngale
 */
import java.util.Scanner;

/** Reads user input, creates a RoadAccidentReport and prints it. */
public class RunApplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the console type: ");
        String type = input.nextLine();

        System.out.print("Enter the city for the console: ");
        String city = input.nextLine();

        System.out.print("Enter the total " + type + " accidents for " + city + ": ");
        int total = input.nextInt();

        

        input.close();
    }
}
