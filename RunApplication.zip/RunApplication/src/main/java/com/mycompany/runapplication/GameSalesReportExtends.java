/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runapplication;

/**
 *
 * @author ngale
 */
public class GameSalesReportExtends {
    

    @Override
    public void printAccidentReport() {
        System.out.println("CONSOLE GAME REPORT");
        System.out.println("***********************");
        System.out.println("CONSOLE TYPE: " + getAccidentVehicleType());
        System.out.println("CITY: " + getCity());
        System.out.println("AMMOUNT TOTAL: " + getAccidentTotal());
        System.out.println("***********************");
}
